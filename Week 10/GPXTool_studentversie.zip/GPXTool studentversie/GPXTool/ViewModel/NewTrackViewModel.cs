﻿using GalaSoft.MvvmLight.Command;
using GPXTool.Data;
using GPXTool.Models;
using GPXTool.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.Storage.Pickers;

namespace GPXTool.ViewModel
{
    public class NewTrackViewModel : ViewModelBaseClass
    {
    }
}
